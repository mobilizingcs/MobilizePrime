InitializeText <- function(variable) {
  return(Corpus(VectorSource(variable)))
}